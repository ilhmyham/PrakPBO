/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PboModul9;

/**
 *
 * @author iam
 */
public class JajarGenjang extends MethodAbs{
    int a = 4;
    int b = 5;
    int t = 3;
    
    public int luas(){
        return a * t; 
    }
    
    public int keliling(){
        return 2 * ( a + b );
    }
}
